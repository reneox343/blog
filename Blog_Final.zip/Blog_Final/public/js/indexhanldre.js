const post = document.getElementById("post");
function getPost(input){
    if(event.key ==='Enter'){
        const title = document.getElementById("title");
        if(title.value != "" && input.value != ""){
            addPost(title.value,input.value);
            
        }
    }
}
function postTitle(input){
    if(event.key ==='Enter'){
        const post = document.getElementById("post");
        if(title.value != "" && input.value != ""){
            addPost(input.value,post.value);
        }
    }
}
function addPost(title,text){
    //date
    const months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "December"];
    const d = new Date()
    const datestring = String(months[d.getMonth()])+"&nbsp;"+ String(d.getDate())+","+"&nbsp;"+String(d.getFullYear());
    //container
    const container =  document.createElement("div")
    container.classList.add("post")
    //img creator
    const imgselector = Math.floor(Math.random() * 7) + 1;
    const image = document.createElement("img")
    image.classList.add("post-image")
    switch (imgselector){
        
        case 1:
            image.src = "./images/neymarchapulin.jpg";
            image.alt = "bichosiuuu";
            break;
        case 2:
            image.src = "./images/bichow.jpg";
            image.alt = "bichow";
            break;
        case 3:   
            image.src = "./images/mbappe.jpg";
            image.alt = "mbappe";
            break;
        case 4:
            image.src = "./images/messispiderman.jpg";
            image.alt = "messispiderman";
                break;
        case 5:   
            image.src= "./images/mbappe.jpg";
            image.alt = "mbappe";
                break;
        case 6:   
            image.src= "./images/seuuuuuuu.jpg";
            image.alt = "seuuuuuuu";
                break;
        case 7:   
            image.src= "./images/bichardo.jpg";
            image.alt = "bichardo";
                break;
    }

    //second conatiner
    const secondcont = document.createElement("div");
    secondcont.classList.add("post-preview");
    //title
    const titlecontainer = document.createElement("h2");
    const a = document.createElement("a");
    a.href = "single.html";
    a.innerHTML = title;
    titlecontainer.appendChild(a);
    //user
    const user = document.createElement("i");
    user.classList.add("far","fa-user");
    user.innerHTML = "Rene Asti Rola";
    //date
    const date = document.createElement("i");
    date.classList.add("far","calendar");
    date.innerHTML = "&nbsp;"+datestring;
    //text post
    const post = document.createElement("p");
    post.innerHTML = text;
    post.classList.add("preview-tex");
    //read more
    const seemore = document.createElement("a");
    seemore.classList.add("btn","read-more");
    seemore.href = "single.html";
    seemore.innerHTML = "Read More"
    //put together
    container.appendChild(image);
    container.appendChild(secondcont);
    secondcont.appendChild(titlecontainer);
    secondcont.appendChild(user);
    secondcont.appendChild(date);
    secondcont.appendChild(post);
    secondcont.appendChild(seemore);
    // add to posted
    const posted = document.getElementById("posted");
    posted.appendChild(container);
}