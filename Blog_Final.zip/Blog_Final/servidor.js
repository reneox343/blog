const express = require("express"); 
const bodyParser = require("body-parser");
const app = express();
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended:true}));


app.get("/", (req,res) => {
    res.sendFile(__dirname+"/index.html");
});
app.get("/single.html", (req,res) => {
    res.sendFile(__dirname+"/single.html");
});
app.listen(3000, ()=> {
    console.log("port 3000")
});
